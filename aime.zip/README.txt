YeMei Tavern / 夜魅酒館-SillyTavern  offline pack
================================================

1. Unzip to Desktop.
2. Double-click game.html   ->  offline chat (no internet needed)
   OR double-click START.bat ->  local window + optional API proxy

API (optional):
- Open 我的
- Paste your xAI API key (xai-...)
- Keep API 開
- START.bat is recommended so the key is proxied (avoids browser CORS)

Without a key, replies stay fully local.
Need Chrome or Edge.
