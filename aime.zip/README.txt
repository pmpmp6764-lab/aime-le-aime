Double-click game.html  (Chrome or Edge)
Unzip first. No START.bat needed.
