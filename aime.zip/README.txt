Double-click START.bat  OR  double-click game.html
Need Chrome or Edge.
Unzip first.
