@echo off
title Aime LIVE
cd /d "%~dp0"

echo.
echo  Aime LIVE  starting...
echo.

if not exist "%~dp0index.html" (
  echo  Cannot find index.html
  echo  Unzip to Desktop first, then double-click START.bat
  echo.
  pause
  exit /b 1
)

set "CHROME="
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "CHROME=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined CHROME if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "CHROME=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"

if defined CHROME (
  echo  Opening game window...
  start "" "%CHROME%" --new-window --app="%~dp0index.html" --window-size=430,780 --window-position=80,40 --no-first-run --no-default-browser-check
) else (
  echo  Chrome/Edge not found. Opening in default browser...
  start "" "%~dp0index.html"
)

echo  Game window should appear now.
echo  You can minimize this black window. Do not close it yet.
echo.
where powershell >nul 2>&1
if errorlevel 1 (
  echo  No PowerShell. Game already opened from file.
  pause
  exit /b 0
)

powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1"
echo.
echo  Server stopped. Press any key to close.
pause
