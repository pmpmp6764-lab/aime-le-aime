@echo off
title YeMei Tavern
cd /d "%~dp0"
echo.
echo  YeMei Tavern  starting...
echo.
if not exist "%~dp0game.html" (
  echo  Cannot find game.html
  echo  Unzip first, then double-click START.bat or game.html
  pause
  exit /b 1
)
set "CHROME="
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "CHROME=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

where powershell >nul 2>&1
if not errorlevel 1 (
  echo  Local server + API proxy...
  powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1"
  goto :eof
)
echo  Opening game.html  (offline only, no API proxy)
if defined CHROME (
  start "" "%CHROME%" --new-window --app="%~dp0game.html" --window-size=430,780 --no-first-run
) else (
  start "" "%~dp0game.html"
)
pause
