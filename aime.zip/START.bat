@echo off
title Aime LIVE
cd /d "%~dp0"
echo.
echo  Opening game.html ...
echo.
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
  start "" "%LocalAppData%\Google\Chrome\Application\chrome.exe" --new-window --app="%~dp0game.html" --window-size=430,780 --no-first-run
) else if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
  start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --new-window --app="%~dp0game.html" --window-size=430,780 --no-first-run
) else if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --new-window --app="%~dp0game.html" --window-size=430,780 --no-first-run
) else (
  start "" "%~dp0game.html"
)
echo  A window should open. You may close this black window.
echo.
timeout /t 6 >nul
