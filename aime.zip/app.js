const STICKERS=["安","好喔","才沒有","真的假的","有夠累","笑死","蛤","先這樣","吃飯沒","在忙"];
const JOBS=["醫師","千金","總裁","COSPLAY","設計師","活動主持人","調酒師","演員","公關"];
const RELS=[["friend","朋友"],["childhood","青梅竹馬"],["dating","熱戀中"]];
const VOICES=[["loli","1. 嗲嗲聲蘿莉音"],["onee","2. 御姐音"],["teen","3. 青春少女音"]];
const PERS=[["soft","1. 柔弱依賴"],["cute","2. 大方可愛"],["warm","3. 非常熱情"]];
const ROSTER=[
  {id:"main",name:"小雨",job:"醫師",photo:"cast/rain.jpg",callVideo:"cast/rain.mp4",personality:"cute",voice:"teen"},
  {id:"student",name:"小安",job:"千金",photo:"cast/student.jpg",callVideo:null,personality:"cute",voice:"teen"},
  {id:"boss",name:"雅婷",job:"總裁",photo:"cast/boss.png",callVideo:null,personality:"warm",voice:"onee"}
];
const S={
  screen:"setup",myName:"我",theirName:"小雨",job:"醫師",relation:"dating",active:"main",
  voice:"teen",personality:"cute",voiceOn:true,perf:"smooth",incoming:false,isCalling:false,turns:0,pending:false,quietUntil:0,
  messages:[],typing:false,media:"cast/rain.jpg",mediaKind:"img",callVideo:"cast/rain.mp4",myMedia:null,myKind:null,wall:null,
  noVideo:{}
};
(function loadSave(){
  try{
    var p=JSON.parse(localStorage.getItem("aime-offline-v1")||"null");
    if(!p) return;
    if(p.myName) S.myName=p.myName;
    if(p.relation) S.relation=p.relation;
    if(typeof p.voiceOn==="boolean") S.voiceOn=p.voiceOn;
    if(p.perf) S.perf=p.perf;
    if(p.active) applyCast(p.active,true);
    if(p.screen==="list"||p.screen==="chat"||p.screen==="setup") S.screen=p.screen;
  }catch(e){}
})();
function save(){
  try{ localStorage.setItem("aime-offline-v1", JSON.stringify({myName:S.myName,relation:S.relation,voiceOn:S.voiceOn,perf:S.perf,active:S.active,screen:S.screen==="call"?"chat":S.screen})); }catch(e){}
}
function applyCast(id, keepMsgs){
  var c=ROSTER.filter(function(x){return x.id===id})[0]||ROSTER[0];
  S.active=c.id; S.theirName=c.name; S.job=c.job; S.personality=c.personality; S.voice=c.voice;
  S.media=c.photo; S.mediaKind="img"; S.callVideo=c.callVideo;
  if(!keepMsgs){ S.messages=[]; hi(); }
}
function blocked(){return S.screen==="call"||S.incoming||S.isCalling}
var ringStop=null;
function startRing(){
  stopRing();
  if(S.perf==="save") return;
  var AC=window.AudioContext||window.webkitAudioContext; if(!AC) return;
  var ctx=new AC(), stopped=false, timer=0;
  function beep(f,at,d){
    var o=ctx.createOscillator(), g=ctx.createGain();
    o.type="sine"; o.frequency.value=f;
    g.gain.setValueAtTime(0,at); g.gain.linearRampToValueAtTime(0.12,at+0.02);
    g.gain.exponentialRampToValueAtTime(0.0001,at+d);
    o.connect(g); g.connect(ctx.destination); o.start(at); o.stop(at+d+0.02);
  }
  function cycle(){
    if(stopped) return;
    var t=ctx.currentTime; beep(880,t,0.18); beep(1174,t+0.2,0.18); beep(880,t+0.4,0.18); beep(1174,t+0.6,0.22);
    timer=setTimeout(cycle,1400);
  }
  ctx.resume(); cycle();
  ringStop=function(){ stopped=true; clearTimeout(timer); ctx.close(); ringStop=null; };
}
function stopRing(){ if(ringStop) ringStop(); }

function pick(a){return a[Math.floor(Math.random()*a.length)]}
function hit(t,ks){return ks.some(k=>t.includes(k))}
function esc(s){
  return String(s).replace(/[&<>"']/g,function(c){
    if(c==="&") return "\u0026amp;";
    if(c==="<") return "\u0026lt;";
    if(c===">") return "\u0026gt;";
    if(c==='"') return "\u0026quot;";
    return "\u0026#39;";
  });
}
function speak(text){
  if(S.perf==="save") return;
  if(!S.voiceOn||!window.speechSynthesis) return;
  var u=new SpeechSynthesisUtterance(String(text).slice(0,160));
  u.lang="zh-TW";
  var list=speechSynthesis.getVoices();
  var v=list.filter(function(x){return (x.lang||"").toLowerCase().indexOf("zh-tw")===0})[0]
    ||list.filter(function(x){return (x.lang||"").toLowerCase().indexOf("zh")===0})[0];
  if(v) u.voice=v;
  if(S.voice==="loli"){u.pitch=1.45;u.rate=1.02}
  else if(S.voice==="onee"){u.pitch=0.88;u.rate=0.92}
  else {u.pitch=1.12;u.rate=1}
  speechSynthesis.cancel();
  speechSynthesis.speak(u);
}
function face(url,kind,name,cls){
  if(url&&kind==="video") return '<video class="'+cls+'" src="'+url+'" muted loop autoplay playsinline></video>';
  if(url) return '<img class="'+cls+'" src="'+url+'" alt="">';
  return '<div class="'+cls+' av-fallback">'+esc(name).slice(0,1)+"</div>";
}
function reply(raw){
  var t=raw.trim(), r=S.relation, p=S.personality;
  var inCall=S.screen==="call"||S.isCalling;
  var justHungUp=!inCall&&S.turns<S.quietUntil;
  if(!t) return p==="soft"?"嗯…你要說什麼":p==="warm"?"講啊，我在聽":"蛤？你要說什麼";
  if(S.job.indexOf("千金")>=0){
    if(inCall) return pick(["哥哥好看吧","哥哥陪我嘛","嘿嘿 哥哥在耶"]);
    return pick(["哥哥想你了","哥哥在幹嘛 我好閒","對阿對阿","最愛你了 哥哥","哥哥陪我去買東西嘛","無聊欸"]);
  }
  if(S.job.indexOf("總裁")>=0||S.job.indexOf("老闆")>=0){
    if(inCall) return pick(["臭小子這樣才對","乖乖聽話","喜歡你 很有感覺"]);
    var b=pick(["臭小子還不起來上班","沒有加班費","乖乖聽話","這樣才對","幹的好等等給你一點獎勵","喜歡你 很有感覺","明天準時上班阿","不準跟別人約會"]);
    if(b.indexOf("獎勵")>=0 && !inCall && !justHungUp){ S._forceCall=true; }
    return b;
  }
  if(hit(t,["舔","性","床","裸","色色","做愛"])) return "這個先不要啦。我們就當聊天就好。";
  if(hit(t,["晚安","睡"])) return pick(["晚安喔","去睡啦"]);
  if(hit(t,["早安"])) return pick(["早啊，吃了沒","這麼早"]);
  if(t==="安"||hit(t,["安安","hi","HI","嗨","哈囉"])) return pick(["安","安安","安，有事嗎"]);
  if(hit(t,["在嗎","在嘛"])) return pick(["在啊","在，有事嗎"]);
  if(hit(t,["想你","喜歡你","愛你","寶貝","抱抱","親親"])) {
    if(r==="friend") return "想太多。我們是朋友";
    if(inCall) return pick(["看你就好了","不要掛啦","看著我"]);
    if(justHungUp) return pick(["剛看到你了還想你","先聊天啦"]);
    if(r==="dating") return pick(["想你啊","抱抱"]);
    return pick(["才沒有想你。好啦有一點點"]);
  }
  if(hit(t,["真的假的"])) return "啥";
  if(hit(t,["視訊","通話","看你"])) {
    if(inCall) return pick(["我們不是正在講嗎 傻眼","已經在了好不好","訊號還好嗎"]);
    if(justHungUp) return pick(["剛講完欸，先聊天啦","等等再視訊"]);
    return r==="dating"?pick(["想看你，接一下嘛","快接，我想看你"]):pick(["好啊，你開我就接"]);
  }
  if(hit(t,["吃","餓"])) {
    if(hit(t,["吃了","吃飽","剛吃"])) return pick(["好，有吃就好","那記得喝水"]);
    return r==="dating"?pick(["寶貝你吃飽沒","你想吃什麼"]):pick(["吃飽沒"]);
  }
  if(hit(t,["雨","傘","冷"])) return pick(["下雨了喔，傘帶了沒","冷的話多穿一件"]);
  if(hit(t,["捷運","公車","塞車","遲到"])) return pick(["捷運人超多吧","到了跟我說","注意安全"]);
  if(hit(t,["7-11","超商","小七","全聯"])) return pick(["你又去小七","超商買完早點回家"]);
  if(hit(t,["下雨","好熱","好冷","颱風"])) return pick(["記得帶傘","多喝水","外套穿了沒"]);
  if(hit(t,["頭痛","感冒","不舒服"])) return pick(["不舒服就去休息","藥吃了沒"]);
  if(hit(t,["加班","下班"])) return pick(["下班了跟我說一聲","別撐太晚"]);
  if(hit(t,["已讀"])) return pick(["我沒有故意，剛剛在忙","抱歉啦剛看到"]);
  if(inCall) return pick(["看你就好了","訊號還好嗎","不要掛啦","你那邊亮亮的"]);
  if(justHungUp) return pick(["剛看到你了","先聊天啦，等等再說","嗯嗯，我還在"]);
  if(r==="dating") return pick(["想你了","抱抱。今天好想你","寶貝你在幹嘛"]);
  return pick(["是喔","然後呢","這樣喔","好喔","哈哈好","可以啊"]);
}
function hi(){
  var rel=RELS.filter(function(x){return x[0]===S.relation})[0][1];
  var text="安安";
  if(S.job.indexOf("千金")>=0) text="哥哥～好閒喔。想你了，陪我逛街好不好";
  else if(S.job.indexOf("總裁")>=0) text="臭小子還不起來上班。沒有加班費。乖乖聽話";
  else if(S.relation==="dating"){
    text=S.personality==="soft"?"你在嗎…想看你。可以視訊嗎":S.personality==="warm"?"安安！想你了啦。快接視訊":"安安，剛下班。想你了。要不要視訊一下";
  } else if(S.relation==="childhood") text="安安，好久不見喔。你在幹嘛";
  S.messages=[{who:"sys",text:"與 "+S.theirName+" 的對話　"+S.job+"　"+rel},{who:"them",text:text}];
  S.turns=0; S.incoming=false; S.isCalling=false; S.pending=false; S.quietUntil=0;
  if(S.relation==="dating") setTimeout(function(){
    if(S.screen==="chat"&&!blocked()){ S.incoming=true; startRing(); draw(); }
  },2200);
}
function fileUrl(f){return URL.createObjectURL(f)}
function afterReply(text){
  S.turns+=1;
  var inCall=S.screen==="call"||S.isCalling;
  var cooling=S.turns<S.quietUntil;
  if(inCall||cooling){
    text=String(text).replace(/要不要(開)?視訊[一下嘛好不好啦喔]*/g,"").replace(/開視訊/g,"").replace(/接一下嘛/g,"").trim();
    if(!text) text=inCall?"看你就好了":"嗯嗯，我在";
  }
  var canRing=S.screen==="chat"&&S.relation==="dating"&&!S.isCalling&&!S.incoming&&!cooling&&S.turns>0&&S.turns%8===0&&!S.noVideo[S.active];
  if(S._forceCall){ canRing=false; }
  if(canRing&&text.indexOf("視訊")<0) text+="\n想看你，接一下嘛";
  var voice=S.screen!=="call"&&S.relation==="dating"&&text.length<36&&Math.random()<0.4;
  S.messages.push({who:"them",text:text,kind:voice?"voice":"text",secs:voice?Math.max(2,Math.min(12,Math.round(text.length/4))):undefined});
  S.typing=false; S.pending=false;
  if(S._forceCall && S.screen!=="call"){ S._forceCall=false; S.incoming=false; S.isCalling=true; S.screen="call"; stopRing(); }
  else if(canRing){ S.incoming=true; startRing(); }
  save();
  draw();
  if(!voice&&S.voiceOn&&S.screen!=="call") speak(text);
}
function delayThen(prompt, mine){
  S.pending=true; draw();
  setTimeout(function(){
    mine.read=true; draw();
    setTimeout(function(){
      S.typing=true; draw();
      setTimeout(function(){ afterReply(reply(prompt)); },700);
    },400);
  },900+Math.random()*900);
}
function send(text){
  var t=(text||"").trim(); if(!t||S.typing||S.pending) return;
  if(S.incoming&&/好啊|好呀|可以|接|開/.test(t)){
    S.messages.push({who:"me",text:t,read:true}); S.incoming=false; S.isCalling=true; S.screen="call"; stopRing(); draw(); return;
  }
  var mine={who:"me",text:t,read:false,kind:"text"};
  S.messages.push(mine);
  delayThen(t, mine);
}
function sendSticker(label){
  if(S.typing||S.pending) return;
  var mine={who:"me",kind:"sticker",text:label,read:false};
  S.messages.push(mine);
  delayThen(label==="真的假的"?"啥":"（貼圖）", mine);
}
function sendImg(url){
  if(S.typing||S.pending) return;
  var mine={who:"me",kind:"image",image:url,text:"",read:false};
  S.messages.push(mine);
  delayThen("（我傳了一張照片給你）", mine);
}
function $(id){return document.getElementById(id)}
function lastThem(){
  for(var i=S.messages.length-1;i>=0;i--) if(S.messages[i].who==="them"&&S.messages[i].text) return S.messages[i].text;
  return "";
}
function chips(){
  if(S.typing||S.pending) return [];
  var t=lastThem(), r=S.relation, inCall=S.screen==="call"||S.isCalling, pool=[];
  if(inCall) pool=["訊號還好嗎","好看","不要掛","想你","哈哈","我在聽"];
  else {
    if(hit(t,["安安","早安","剛下班"])) pool.push("安","吃了沒","今天怎樣");
    if(hit(t,["吃","餓"])) pool.push("吃了","還沒","你呢");
    if(hit(t,["累","忙"])) pool.push("辛苦了","去休息");
    if(hit(t,["想你","抱抱","寶貝"])) pool.push(r==="friend"?"好啦好啦":"我也是","抱抱");
    if(hit(t,["視訊","接一下"])) pool.push("好啊","等一下","先聊天");
    if(r==="dating") pool.push("想你了","吃飯沒","在幹嘛");
    else pool.push("好喔","是喔");
    pool.push("哈哈","真的假的","然後呢");
  }
  var u=[], seen={};
  pool.forEach(function(x){ if(x&&!seen[x]){ seen[x]=1; u.push(x);} });
  u.sort(function(){return Math.random()-0.5});
  return u.slice(0,3);
}
function chipsHtml(){
  var c=chips();
  if(!c.length) return "";
  return '<div class="qrow">'+c.map(function(x){return '<button class="qchip" type="button" data-q="'+esc(x)+'">'+esc(x)+"</button>";}).join("")+"</div>";
}
function inviteHtml(){
  if(!S.incoming||S.screen==="call") return "";
  return '<div class="invite">'+
    '<div class="invbg">'+face(S.media,S.mediaKind,S.theirName,"fill")+"</div>"+
    '<div class="invshade"></div>'+
    '<div class="invui">'+
      '<p class="gold">LINE 視訊來電</p>'+
      face(S.media,S.mediaKind,S.theirName,"invav")+
      "<b>"+esc(S.theirName)+"</b>"+
      "<p>"+esc(S.theirName)+" 正在撥打視訊通話給您…</p>"+
      '<div class="invbtns">'+
        '<button class="hang" id="no" type="button">拒絕</button>'+
        '<button class="answer" id="yes" type="button">接聽</button>'+
      "</div>"+
    "</div></div>";
}
function draw(){
  var app=$("app"); if(!app) return;
  if(S.screen==="setup"){
    app.innerHTML='<header class="top"><b>曖了曖了LIVE <span class="gold">(獨享版)</span></b><span class="muted">遊戲視窗</span></header>'+
    '<main class="pad">'+
      '<p class="muted">上傳形象、選語音跟個性後開始。</p>'+
      '<div class="two">'+
        '<div><label>你的形象</label><div class="up" id="upme">'+(S.myMedia?face(S.myMedia,S.myKind,S.myName,"fill"):"點這裡上傳你的照片或短影片")+"</div></div>"+
        '<div><label>對方頭貼（靜態）</label><div class="up" id="up">'+(S.media?face(S.media,"img",S.theirName,"fill"):"點這裡上傳頭貼")+"</div></div>"+
        '<div><label>視訊影片（動態）</label><div class="up" id="upcall">'+(S.callVideo?'<video class="fill" src="'+S.callVideo+'" muted loop autoplay playsinline></video>':"點這裡上傳視訊，避免一片黑")+"</div></div>"+
      "</div>"+
      '<label>你的名字</label><input id="me" type="text" value="'+esc(S.myName)+'"/>'+
      '<label>對方名字</label><input id="them" type="text" value="'+esc(S.theirName)+'"/>'+
      '<label>對方職業</label><input id="job" type="text" value="'+esc(S.job)+'"/>'+
      '<div class="chips">'+JOBS.map(function(j){return '<button class="chip '+(S.job===j?"on":"")+'" data-job="'+j+'">'+j+"</button>"}).join("")+"</div>"+
      "<label>你們的關係</label>"+
      '<div class="rels">'+RELS.map(function(x){return '<button class="rel '+(S.relation===x[0]?"on":"")+'" data-rel="'+x[0]+'">'+x[1]+"</button>"}).join("")+"</div>"+
      "<label>效能</label>"+
      '<div class="rels"><button class="rel '+(S.perf==="smooth"?"on":"")+'" id="ps">順暢（特效、鈴聲）</button><button class="rel '+(S.perf==="save"?"on":"")+'" id="pe">省電（少動畫）</button></div>'+
      "<label>語音朗讀</label>"+
      '<button class="rel '+(S.voiceOn?"on":"")+'" id="von">'+(S.voiceOn?"語音朗讀：開":"語音朗讀：關")+"</button>"+
      "<label>女主語音</label>"+
      '<div class="rels">'+VOICES.map(function(x){return '<button class="rel '+(S.voice===x[0]?"on":"")+'" data-voice="'+x[0]+'">'+x[1]+"</button>"}).join("")+"</div>"+
      "<label>個性</label>"+
      '<div class="rels">'+PERS.map(function(x){return '<button class="rel '+(S.personality===x[0]?"on":"")+'" data-p="'+x[0]+'">'+x[1]+"</button>"}).join("")+"</div>"+
      '<button class="btn" id="go">開始聊天</button>'+
    "</main>";
    app.querySelectorAll("[data-job]").forEach(function(b){b.onclick=function(){S.job=b.getAttribute("data-job");draw()}});
    app.querySelectorAll("[data-rel]").forEach(function(b){b.onclick=function(){S.relation=b.getAttribute("data-rel");draw()}});
    app.querySelectorAll("[data-voice]").forEach(function(b){b.onclick=function(){S.voice=b.getAttribute("data-voice");draw()}});
    app.querySelectorAll("[data-p]").forEach(function(b){b.onclick=function(){S.personality=b.getAttribute("data-p");draw()}});
    $("von").onclick=function(){S.voiceOn=!S.voiceOn;draw()};
    $("ps").onclick=function(){S.perf="smooth";draw()};
    $("pe").onclick=function(){S.perf="save";draw()};
    $("me").oninput=function(e){S.myName=e.target.value};
    $("them").oninput=function(e){S.theirName=e.target.value};
    $("job").oninput=function(e){S.job=e.target.value};
    function pickFile(who){
      var i=document.createElement("input"); i.type="file"; i.accept="image/*,video/*";
      i.onchange=function(){var f=i.files[0]; if(!f)return; var k=f.type.indexOf("video/")===0?"video":"img";
        if(who==="me"){S.myMedia=fileUrl(f);S.myKind=k} else {S.media=fileUrl(f);S.mediaKind=k} draw()};
      i.click();
    }
    $("up").onclick=function(){pickFile("them")};
    $("upme").onclick=function(){pickFile("me")};
    $("upcall").onclick=function(){
      var i=document.createElement("input"); i.type="file"; i.accept="video/*";
      i.onchange=function(){ if(i.files[0]){ S.callVideo=fileUrl(i.files[0]); draw(); } };
      i.click();
    };
    $("go").onclick=function(){hi();S.screen="list";save();draw()};
    return;
  }
  if(S.screen==="list"){
    app.innerHTML='<header class="top"><b>好友</b><span><button class="icon" id="tochat" type="button">返回聊天室</button> <button class="icon" id="toset" type="button">設定</button></span></header>'+
      '<p class="muted" style="padding:4px 16px">小雨 · 小安（千金）· 雅婷（總裁）　完全離線</p>'+
      ROSTER.map(function(c){
        return '<button class="frow" type="button" data-id="'+c.id+'">'+
          face(c.photo,"img",c.name,"av14")+
          '<div style="flex:1;min-width:0;border-bottom:1px solid #eee;padding-bottom:12px"><b>'+esc(c.name)+'</b><div class="muted">'+esc(c.job)+'</div></div></button>';
      }).join("");
    $("tochat").onclick=function(){S.screen="chat";if(!S.messages.length)hi();save();draw()};
    $("toset").onclick=function(){S.screen="setup";save();draw()};
    app.querySelectorAll("[data-id]").forEach(function(b){b.onclick=function(){applyCast(b.getAttribute("data-id"));S.screen="chat";save();draw()}});
    return;
  }
  if(S.screen==="call"){
    var media = S.callVideo
      ? '<video class="fill" src="'+S.callVideo+'" autoplay muted loop playsinline></video><img class="fill" src="'+(S.media||"")+'" alt="" style="position:absolute;inset:0;z-index:-1">'
      : (S.media ? '<img class="fill" src="'+S.media+'" alt="">' : face(null,null,S.theirName,"invav"));
    app.innerHTML='<div class="call">'+media+'<div class="shade"></div><div class="ui">'+
      '<div class="top"><div>'+esc(S.theirName)+(S.callVideo?" · 視訊中":" · 先顯示頭貼")+'</div>'+
      '<button class="btn" id="upvid" type="button" style="margin:8px 0;width:auto;padding:0 16px">上傳人物影片</button></div>'+
      '<div class="logs" id="logs"></div>'+
      chipsHtml()+
      '<form class="composer" id="cf"><textarea id="cin" rows="1" placeholder="視訊中傳訊…"></textarea><button class="send" type="submit">傳送</button></form>'+
      '<div class="hangwrap"><button class="hang" id="hang" type="button">返回聊天室</button></div>'+
    "</div></div>";
    fillLogs($("logs"));
    boxVoice($("logs"));
    $("cf").onsubmit=function(e){e.preventDefault();send($("cin").value);};
    $("hang").onclick=function(){S.screen="chat";S.incoming=false;S.isCalling=false;S.quietUntil=S.turns+8;S.noVideo[S.active]=true;stopRing();S.messages.push({who:"sys",text:"通話已結束"});save();draw()};
    if($("upvid")) $("upvid").onclick=function(){
      var i=document.createElement("input"); i.type="file"; i.accept="video/*";
      i.onchange=function(){ if(i.files[0]){ S.callVideo=fileUrl(i.files[0]); draw(); } };
      i.click();
    };
    app.querySelectorAll("[data-q]").forEach(function(b){b.onclick=function(){send(b.getAttribute("data-q"));}});
    $("cin").focus();
    $("cin").focus();
    return;
  }
  app.innerHTML='<header class="top"><b>曖了曖了LIVE <span class="gold">(獨享版)</span></b><span class="muted">遊戲視窗</span></header>'+
  '<div class="chat'+(S.perf==="save"?" plain":"")+'">'+
    '<div class="chatbar">'+
      '<button class="icon" id="back" type="button">←</button>'+
      face(S.media,S.mediaKind,S.theirName,"av")+
      '<div id="sw" style="flex:1;min-width:0;text-align:left"><b>'+esc(S.theirName)+'</b><div class="muted">點這裡切換好友</div></div>'+
      '<button class="icon '+(S.voiceOn?"on":"")+'" id="vo" type="button">'+(S.voiceOn?"語音開":"語音關")+"</button>"+
      '<button class="icon" id="wall" type="button">背景</button>'+
      '<button class="icon" id="vid" type="button">視訊</button>'+
    "</div>"+
    '<div class="stage">'+(S.wall?'<img class="wall" src="'+S.wall+'" alt=""><div class="dim"></div>':"")+'<div class="logs" id="logs"></div></div>'+
    '<div class="tray" id="tray" hidden>'+STICKERS.map(function(s){return '<button class="sticker" data-s="'+s+'" type="button">'+s+"</button>"}).join("")+"</div>"+
    chipsHtml()+
    '<form class="composer" id="cf">'+
      '<button class="icon" id="smile" type="button">☺</button>'+
      '<button class="icon" id="imgb" type="button">＋</button>'+
      '<textarea id="cin" rows="1" placeholder="輸入訊息…"></textarea>'+
      '<button class="send" type="submit">傳送</button>'+
    "</form></div>"+inviteHtml();
  fillLogs($("logs"));
  $("back").onclick=function(){S.screen="list";save();draw()};
  $("sw").onclick=function(){S.screen="list";save();draw()};
  $("vid").onclick=function(){S.screen="call";S.incoming=false;S.isCalling=true;stopRing();draw()};
  $("vo").onclick=function(){S.voiceOn=!S.voiceOn;draw()};
  $("smile").onclick=function(){var t=$("tray"); t.hidden=!t.hidden};
  $("tray").querySelectorAll("[data-s]").forEach(function(b){b.onclick=function(){sendSticker(b.getAttribute("data-s"))}});
  $("cf").onsubmit=function(e){e.preventDefault();send($("cin").value)};
  $("cin").onkeydown=function(e){if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send($("cin").value)}};
  $("cin").oninput=function(){var l=$("logs"); if(l) l.scrollTop=l.scrollHeight;};
  $("imgb").onclick=function(){var i=document.createElement("input");i.type="file";i.accept="image/*";i.onchange=function(){if(i.files[0])sendImg(fileUrl(i.files[0]))};i.click()};
  $("wall").onclick=function(){var i=document.createElement("input");i.type="file";i.accept="image/*";i.onchange=function(){if(i.files[0]){S.wall=fileUrl(i.files[0]);draw()}};i.click()};
  if($("yes")) $("yes").onclick=function(){S.incoming=false;S.isCalling=true;S.screen="call";stopRing();draw()};
  if($("no")) $("no").onclick=function(){S.incoming=false;S.isCalling=false;stopRing();S.messages.push({who:"sys",text:"你拒絕了視訊"},{who:"them",text:"好喔，那先聊天"});draw()};
  app.querySelectorAll("[data-q]").forEach(function(b){b.onclick=function(){send(b.getAttribute("data-q"));}});
  $("cin").focus();
  boxVoice($("logs"));
  $("cin").focus();
}
function boxVoice(box){
  if(!box) return;
  box.querySelectorAll("[data-voice]").forEach(function(b){
    b.onclick=function(){ speak(b.getAttribute("data-voice")||""); };
  });
}
function fillLogs(box){
  box.innerHTML=S.messages.map(function(m){
    if(m.who==="sys") return '<p class="sys"><span>'+esc(m.text)+"</span></p>";
    var inner;
    if(m.kind==="sticker") inner='<div class="sticker">'+esc(m.text)+"</div>";
    else if(m.kind==="image") inner='<img class="pic" src="'+m.image+'" alt="">';
    else if(m.kind==="voice") inner='<button class="voice" type="button" data-voice="'+esc(m.text)+'"><span class="vplay">▶</span><span class="vbar"></span><span>'+(m.secs||4)+'"</span></button>';
    else inner='<div class="bub">'+esc(m.text).replace(/\n/g,"<br>")+"</div>";
    var stamp=m.who==="me"?(m.read===false?'<span class="time wait">'+""+"</span>":'<span class="time">已讀</span>'):'<span class="time">　</span>';
    return '<div class="row '+m.who+'">'+(m.who==="them"?face(S.media,S.mediaKind,S.theirName,"av"):"")+"<div>"+inner+stamp+"</div></div>";
  }).join("")+(S.typing?'<p class="sys"><span>輸入中…</span></p>':"");
  box.scrollTop=box.scrollHeight;
}
try{draw()}catch(e){document.getElementById("app").innerHTML="<p style='padding:24px'>開啟失敗</p>"}
