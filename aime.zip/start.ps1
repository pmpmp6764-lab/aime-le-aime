﻿$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$html = Join-Path $root "index.html"
try { $host.UI.RawUI.WindowTitle = "Aime LIVE" } catch {}

if (-not (Test-Path -LiteralPath $html)) {
  Write-Host "index.html not found"
  Start-Sleep -Seconds 5
  exit 1
}

function MimeOf([string]$ext) {
  switch ($ext) {
    ".html" { "text/html; charset=utf-8" }
    ".js"   { "text/javascript; charset=utf-8" }
    ".css"  { "text/css; charset=utf-8" }
    ".svg"  { "image/svg+xml" }
    ".jpg"  { "image/jpeg" }
    ".png"  { "image/png" }
    ".gif"  { "image/gif" }
    ".webp" { "image/webp" }
    ".mp4"  { "video/mp4" }
    ".webm" { "video/webm" }
    ".json" { "application/json; charset=utf-8" }
    default { "application/octet-stream" }
  }
}

function Send-File($ctx, [string]$full, [string]$mime) {
  $fs = [IO.File]::Open($full, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
  try {
    $len = $fs.Length
    $start = [int64]0
    $end = $len - 1
    $status = 200
    $range = $ctx.Request.Headers["Range"]
    if ($range -and $range -match "bytes=(\d*)-(\d*)") {
      if ($Matches[1] -ne "") { $start = [int64]$Matches[1] }
      if ($Matches[2] -ne "") { $end = [int64]$Matches[2] }
      if ($end -ge $len) { $end = $len - 1 }
      if ($start -gt $end) { $start = 0 }
      $status = 206
      $ctx.Response.AddHeader("Content-Range", "bytes $start-$end/$len")
    }
    $count = $end - $start + 1
    $ctx.Response.StatusCode = $status
    $ctx.Response.ContentType = $mime
    $ctx.Response.AddHeader("Accept-Ranges", "bytes")
    $ctx.Response.AddHeader("Cache-Control", "no-store")
    $ctx.Response.ContentLength64 = $count
    $fs.Position = $start
    $buf = New-Object byte[] 65536
    $left = $count
    while ($left -gt 0) {
      $n = $fs.Read($buf, 0, [Math]::Min($buf.Length, $left))
      if ($n -le 0) { break }
      $ctx.Response.OutputStream.Write($buf, 0, $n)
      $left -= $n
    }
  } finally {
    $fs.Close()
    try { $ctx.Response.OutputStream.Close() } catch {}
    $ctx.Response.Close()
  }
}

$listener = $null
$port = 0
foreach ($p in 18765..18785) {
  try {
    $tmp = New-Object System.Net.HttpListener
    $tmp.Prefixes.Add("http://127.0.0.1:$p/")
    $tmp.Start()
    $listener = $tmp
    $port = $p
    break
  } catch {
    try { $tmp.Close() } catch {}
  }
}

if (-not $listener) {
  Write-Host "Local server not started. Game window already opened from file."
  while ($true) { Start-Sleep -Seconds 60 }
}

Write-Host ("Local server ok  http://127.0.0.1:" + $port + "/")
$rootFull = [IO.Path]::GetFullPath($root)
while ($listener.IsListening) {
  try {
    $ctx = $listener.GetContext()
    $rel = [Uri]::UnescapeDataString($ctx.Request.Url.LocalPath.TrimStart("/"))
    if ([string]::IsNullOrWhiteSpace($rel) -or $rel -eq "/") { $rel = "index.html" }
    $full = [IO.Path]::GetFullPath((Join-Path $root $rel))
    if (-not $full.StartsWith($rootFull, [StringComparison]::OrdinalIgnoreCase)) {
      $ctx.Response.StatusCode = 403
      $ctx.Response.Close()
      continue
    }
    if (-not (Test-Path -LiteralPath $full) -or (Get-Item -LiteralPath $full).PSIsContainer) {
      $ctx.Response.StatusCode = 404
      $ctx.Response.Close()
      continue
    }
    Send-File $ctx $full (MimeOf ([IO.Path]::GetExtension($full).ToLowerInvariant()))
  } catch {
    Start-Sleep -Milliseconds 80
  }
}
