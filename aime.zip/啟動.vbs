Set sh = CreateObject("Wscript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir
' 0=hidden would look like 沒反應；用一般視窗啟動比較穩
sh.Run "cmd /c START.bat", 1, False
