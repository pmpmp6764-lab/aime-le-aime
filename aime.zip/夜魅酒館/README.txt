夜魅酒館 桌面版
================

1. 把整個資料夾解壓縮到「桌面」（不要在壓縮檔裡面點）。
2. 進入資料夾，雙擊 START.bat
   - 會開遊戲視窗（Chrome / Edge）
   - 有 API 金鑰時可走雲端
3. 若 START.bat 打不開，改雙擊 game.html

使用：
- 我的 → 上傳角色卡、視訊
- 可選：貼 xAI API 金鑰（console.x.ai）讓對話更聰明
- 不填金鑰也能單機玩

需要 Chrome 或 Edge。
