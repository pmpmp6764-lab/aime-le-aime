﻿$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$html = Join-Path $root "game.html"
try { $host.UI.RawUI.WindowTitle = "YeMei Tavern" } catch {}

function MimeOf([string]$ext) {
  switch ($ext) {
    ".html" { "text/html; charset=utf-8" }
    ".js"   { "text/javascript; charset=utf-8" }
    ".css"  { "text/css; charset=utf-8" }
    ".jpg"  { "image/jpeg" }
    ".png"  { "image/png" }
    ".mp4"  { "video/mp4" }
    ".json" { "application/json; charset=utf-8" }
    default { "application/octet-stream" }
  }
}

function Send-Bytes($ctx, [int]$code, [string]$mime, [byte[]]$bytes) {
  $ctx.Response.StatusCode = $code
  $ctx.Response.ContentType = $mime
  $ctx.Response.AddHeader("Access-Control-Allow-Origin", "*")
  $ctx.Response.ContentLength64 = $bytes.Length
  $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $ctx.Response.Close()
}

function Handle-Chat($ctx) {
  $sr = New-Object IO.StreamReader($ctx.Request.InputStream, [Text.Encoding]::UTF8)
  $raw = $sr.ReadToEnd()
  $sr.Close()
  $obj = $raw | ConvertFrom-Json
  $key = [string]$obj.apiKey
  $payload = $obj.payload
  if (-not $key) {
    Send-Bytes $ctx 400 "application/json; charset=utf-8" ([Text.Encoding]::UTF8.GetBytes('{"error":"no-key"}'))
    return
  }
  $body = $payload | ConvertTo-Json -Depth 12 -Compress
  try {
    $res = Invoke-RestMethod -Method Post -Uri "https://api.x.ai/v1/chat/completions" -ContentType "application/json" -Headers @{ Authorization = "Bearer $key" } -Body $body -TimeoutSec 20
    $text = ""
    try { $text = $res.choices[0].message.content } catch {}
    $out = @{ reply = $text } | ConvertTo-Json -Compress
    Send-Bytes $ctx 200 "application/json; charset=utf-8" ([Text.Encoding]::UTF8.GetBytes($out))
  } catch {
    Send-Bytes $ctx 502 "application/json; charset=utf-8" ([Text.Encoding]::UTF8.GetBytes('{"error":"fail"}'))
  }
}

$listener = $null
$port = 0
foreach ($p in 18765..18785) {
  try {
    $tmp = New-Object System.Net.HttpListener
    $tmp.Prefixes.Add("http://127.0.0.1:$p/")
    $tmp.Start()
    $listener = $tmp
    $port = $p
    break
  } catch { try { $tmp.Close() } catch {} }
}

function Open-Game([string]$target) {
  $browsers = @(
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"
  )
  foreach ($b in $browsers) {
    if (Test-Path -LiteralPath $b) {
      Start-Process -FilePath $b -ArgumentList "--new-window","--app=$target","--window-size=430,780","--no-first-run"
      return
    }
  }
  Start-Process $html
}

if (-not $listener) {
  Write-Host "No local server. Opening game.html"
  Open-Game ((Get-Item $html).FullName)
  while ($true) { Start-Sleep 60 }
}

Write-Host ("OK  http://127.0.0.1:" + $port + "/")
Open-Game ("http://127.0.0.1:$port/game.html")
$rootFull = [IO.Path]::GetFullPath($root)
while ($listener.IsListening) {
  try {
    $ctx = $listener.GetContext()
    if ($ctx.Request.HttpMethod -eq "OPTIONS") {
      $ctx.Response.AddHeader("Access-Control-Allow-Origin", "*")
      $ctx.Response.AddHeader("Access-Control-Allow-Headers", "*")
      $ctx.Response.StatusCode = 204
      $ctx.Response.Close()
      continue
    }
    if ($ctx.Request.Url.LocalPath -eq "/api/chat") {
      Handle-Chat $ctx
      continue
    }
    $rel = [Uri]::UnescapeDataString($ctx.Request.Url.LocalPath.TrimStart("/"))
    if ([string]::IsNullOrWhiteSpace($rel) -or $rel -eq "/") { $rel = "game.html" }
    $full = [IO.Path]::GetFullPath((Join-Path $root $rel))
    if (-not $full.StartsWith($rootFull, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $full)) {
      $ctx.Response.StatusCode = 404
      $ctx.Response.Close()
      continue
    }
    $bytes = [IO.File]::ReadAllBytes($full)
    Send-Bytes $ctx 200 (MimeOf ([IO.Path]::GetExtension($full).ToLowerInvariant())) $bytes
  } catch { Start-Sleep -Milliseconds 50 }
}
